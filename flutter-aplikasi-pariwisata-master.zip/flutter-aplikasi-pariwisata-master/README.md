# dw_pariwisata

Belajar Flutter Basic #7: Navigation Aplikasi Pariwisata

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Artikel: Belajar Flutter Basic #7: Navigation Aplikasi Pariwisata](https://daengweb.id/belajar-flutter-basic-7-navigation-aplikasi-pariwisata)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
